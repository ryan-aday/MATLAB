%Ryan Aday
%112754800
%MEC 102
%HW #02

clear all
clc

SBUID=112754800;

%Problem #3

x=1:0.1:10;
y=1:0.1:10;
[X,Y]=meshgrid(x,y);
Z=sin(X).*cos(Y);
surfc(X,Y,Z);