%Ryan Aday
%112754800
%MEC 102
%HW #02

clear all
clc

SBUID=112754800;

%Problem #2

A=[-1 1 3;
    1 3 5;
    -2 0 2;];
B=[1; 3; 0;];

%a)
rref([A B]);

%Results:
%     1     0    -1     0
%    0     1     2     1
%    0     0     0     0

%b)
x3=-1:0.1:3;


%x3 is independent
%x1 = x3
%x2 = 1 - 2*x3

%c) 
x1=x3;
x2 = 1 - 2*x3
plot(x3,x1,'k')
hold on;
plot(x3,x2,'r')
grid on;
axis tight;